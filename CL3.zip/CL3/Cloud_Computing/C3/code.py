Chutiya. Hahah
Khali VmWare chalana hai
